from setuptools import setup, find_packages

setup(
    name='mi_paquete',
    version='1.0',
    packages=find_packages(),
    description='Esto es un paquete distribuible de Python',
    author='Claudio Pacheco',
    author_email='clapache@gmail.com',
)
